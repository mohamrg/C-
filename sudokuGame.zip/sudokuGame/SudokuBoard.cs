// File: SudokuBoard.cs
using System;

namespace SudokuGame
{
    class SudokuBoard
    {
        private int[,] board;

        public SudokuBoard()
        {
            board = new int[9, 9]
            {
                { 5, 3, 0, 0, 7, 0, 0, 0, 0 },
                { 6, 0, 0, 1, 9, 5, 0, 0, 0 },
                { 0, 9, 8, 0, 0, 0, 0, 6, 0 },
                { 8, 0, 0, 0, 6, 0, 0, 0, 3 },
                { 4, 0, 0, 8, 0, 3, 0, 0, 1 },
                { 7, 0, 0, 0, 2, 0, 0, 0, 6 },
                { 0, 6, 0, 0, 0, 0, 2, 8, 0 },
                { 0, 0, 0, 4, 1, 9, 0, 0, 5 },
                { 0, 0, 0, 0, 8, 0, 0, 7, 9 }
            };
        }

        public void PrintBoard()
        {
            Console.WriteLine("   1 2 3   4 5 6   7 8 9");
            for (int i = 0; i < 9; i++)
            {
                if (i % 3 == 0) Console.WriteLine("  +-------+-------+-------+");
                Console.Write((i + 1) + " | ");
                for (int j = 0; j < 9; j++)
                {
                    Console.Write(board[i, j] == 0 ? ". " : board[i, j] + " ");
                    if ((j + 1) % 3 == 0) Console.Write("| ");
                }
                Console.WriteLine();
            }
            Console.WriteLine("  +-------+-------+-------+");
        }

        public bool IsValidMove(int row, int col, int value)
        {
            if (row < 0 || row >= 9 || col < 0 || col >= 9 || value < 1 || value > 9 || board[row, col] != 0)
                return false;

            for (int i = 0; i < 9; i++)
            {
                if (board[row, i] == value || board[i, col] == value)
                    return false;
            }

            int startRow = (row / 3) * 3;
            int startCol = (col / 3) * 3;
            for (int i = startRow; i < startRow + 3; i++)
            {
                for (int j = startCol; j < startCol + 3; j++)
                {
                    if (board[i, j] == value)
                        return false;
                }
            }

            return true;
        }

        public bool MakeMove(int row, int col, int value)
        {
            if (IsValidMove(row, col, value))
            {
                board[row, col] = value;
                return true;
            }
            return false;
        }

        public bool IsComplete()
        {
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    if (board[i, j] == 0)
                        return false;
                }
            }
            return true;
        }
    }
}




